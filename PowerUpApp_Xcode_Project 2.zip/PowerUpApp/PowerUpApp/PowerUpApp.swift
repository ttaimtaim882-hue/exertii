import SwiftUI

@main
struct PowerUpApp: App {
    var body: some Scene {
        WindowGroup {
            PowerUpDemoView()
        }
    }
}
