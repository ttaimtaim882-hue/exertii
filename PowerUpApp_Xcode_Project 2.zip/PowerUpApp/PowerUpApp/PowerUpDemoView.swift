import SwiftUI

// Standalone cosmetic demo. Not wired to game patching, injection, remote APIs, or exploit code.
struct PowerUpDemoView: View {
    @AppStorage("powerup_demo_unlocked") private var unlocked = false
    @State private var code = ""
    @State private var showError = false

    private let groupURL = URL(string: "https://t.me/UP_POWER1")!
    private let demoCode = "POWER"

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            RadialGradient(colors: [Color.blue.opacity(0.30), .black], center: .top, startRadius: 20, endRadius: 500)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Spacer(minLength: 40)
                
                // Logo أصغر + نازل شوي
                Image("POWERUPLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 220, maxHeight: 200)
                    .padding(.bottom, 8)
                
                Text("POWER UP")
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(.white)
                
                if unlocked {
                    // الواجهة بعد الدخول كما هي
                    VStack(spacing: 16) {
                        Label("ACCESS GRANTED", systemImage: "checkmark.shield.fill")
                            .font(.headline)
                            .foregroundStyle(.blue)
                        
                        Button {
                            UIApplication.shared.open(groupURL)
                        } label: {
                            Label("TELEGRAM GROUP", systemImage: "paperplane.fill")
                                .frame(maxWidth: .infinity)
                                .padding()
                        }
                        .buttonStyle(BlueButton())
                        
                        Button("LOG OUT", systemImage: "rectangle.portrait.and.arrow.right") {
                            unlocked = false
                        }
                        .foregroundStyle(.white.opacity(0.85))
                    }
                    .padding(.top, 12)
                } else {
                    VStack(spacing: 14) {
                        SecureField("Enter access code", text: $code)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .padding(15)
                            .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(.blue.opacity(0.55), lineWidth: 1))
                            .foregroundStyle(.white)
                        
                        // زر تسجيل الدخول معدل
                        Button {
                            if code.trimmingCharacters(in: .whitespacesAndNewlines).uppercased() == demoCode {
                                unlocked = true
                                showError = false
                                code = ""
                            } else {
                                showError = true
                            }
                        } label: {
                            Text("LOGIN")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                        }
                        .buttonStyle(BlueButton())
                        
                        if showError {
                            Text("Incorrect code")
                                .foregroundStyle(.red)
                                .font(.subheadline)
                        }
                        
                        Button {
                            UIApplication.shared.open(groupURL)
                        } label: {
                            Label("JOIN TELEGRAM", systemImage: "paperplane.fill")
                        }
                        .foregroundStyle(.blue)
                        .padding(.top, 4)
                    }
                    .padding(.top, 10)
                }
                
                Spacer(minLength: 30)
                
                Text("POWER UP • DEMO INTERFACE")
                    .font(.caption2.weight(.bold))
                    .tracking(1.2)
                    .foregroundStyle(.white.opacity(0.45))
                    .padding(.bottom, 10)
            }
            .padding(.horizontal, 24)
        }
        .preferredColorScheme(.dark)
    }
}

private struct BlueButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline.weight(.bold))
            .foregroundStyle(.white)
            .background(
                LinearGradient(
                    colors: [Color.blue, Color.cyan.opacity(0.85)],
                    startPoint: .leading,
                    endPoint: .trailing
                ),
                in: RoundedRectangle(cornerRadius: 14)
            )
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .opacity(configuration.isPressed ? 0.9 : 1)
    }
}
