import SwiftUI

// Standalone cosmetic demo. Not wired to game patching, injection, remote APIs, or exploit code.
struct PowerUpDemoView: View {
    @AppStorage("powerup_demo_unlocked") private var unlocked = false
    @State private var code = ""
    @State private var showError = false

    private let groupURL = URL(string: "https://t.me/UP_POWER1")!
    private let demoCode = "POWER"

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            RadialGradient(colors: [Color.blue.opacity(0.30), .black], center: .top, startRadius: 20, endRadius: 500)
                .ignoresSafeArea()
            VStack(spacing: 24) {
                Spacer()
                Image("POWERUPLogo")
                    .resizable().scaledToFit().frame(maxWidth: 300, maxHeight: 290)
                Text("POWER UP")
                    .font(.system(size: 32, weight: .black, design: .rounded))
                    .tracking(2).foregroundStyle(.white)
                if unlocked {
                    VStack(spacing: 16) {
                        Label("ACCESS GRANTED", systemImage: "checkmark.shield.fill")
                            .font(.headline).foregroundStyle(.blue)
                        Button { UIApplication.shared.open(groupURL) } label: {
                            Label("TELEGRAM GROUP", systemImage: "paperplane.fill")
                                .frame(maxWidth: .infinity).padding()
                        }
                        .buttonStyle(BlueButton())
                        Button("LOG OUT", systemImage: "rectangle.portrait.and.arrow.right") { unlocked = false }
                            .foregroundStyle(.white.opacity(0.85))
                    }
                } else {
                    VStack(spacing: 12) {
                        SecureField("Enter access code", text: $code)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .padding(15)
                            .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(.blue.opacity(0.55), lineWidth: 1))
                            .foregroundStyle(.white)
                        Button("LOGIN") {
                            if code.trimmingCharacters(in: .whitespacesAndNewlines).uppercased() == demoCode {
                                unlocked = true; showError = false; code = ""
                            } else { showError = true }
                        }
                        .buttonStyle(BlueButton())
                        if showError { Text("Incorrect code").foregroundStyle(.red) }
                        Button { UIApplication.shared.open(groupURL) } label: {
                            Label("JOIN TELEGRAM", systemImage: "paperplane.fill")
                        }.foregroundStyle(.blue)
                    }
                }
                Spacer()
                Text("POWER UP • DEMO INTERFACE")
                    .font(.caption2.weight(.bold)).tracking(1.2).foregroundStyle(.white.opacity(0.45))
            }
            .padding(24)
        }
        .preferredColorScheme(.dark)
    }
}

private struct BlueButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline.weight(.bold))
            .foregroundStyle(.white)
            .background(LinearGradient(colors: [Color.blue, Color.cyan.opacity(0.85)], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 14))
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }
}
